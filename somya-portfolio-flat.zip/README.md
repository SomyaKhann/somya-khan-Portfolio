# Somya Khan — Portfolio (flat version)

All files live in one folder, no subfolders.

## Add a project
1. Upload the thumbnail (e.g. `skyline.jpg`) to the repo's main page with Add file → Upload files.
2. Upload the full video to unlisted YouTube/Vimeo and copy the link.
3. Open `projects.json`, click the pencil, add an entry (copy one from `projects.example.json`) with `"thumbnail": "skyline.jpg"`. Separate entries with commas.
4. Commit. Wait 1–2 minutes.

Settings like contact links, showreel and talking-head videos are in `site.json`. Categories: real-estate, ai, brand, motion. Add `?demo` to the site URL to preview sample projects.
